package com.classpath.flux;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import java.util.function.BiFunction;
import java.util.function.Function;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.reactivestreams.Publisher;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.util.function.Tuple3;

public class FluxTests {

	private Flux<Integer> integerFlux;
	
	@BeforeEach
	void initializeFlux() {
		 integerFlux = Flux.just(11, 22, 33, 44);
	}
	@Test
	void testFluxOperator() {
		
		Flux<Integer> evenFlux = integerFlux.filter(number -> number % 2 == 0);
		Flux<Integer> oddFlux = integerFlux.filter(number -> number % 2 != 0);

		StepVerifier.create(evenFlux).expectNext(22, 44).expectComplete().verify();
		StepVerifier.create(oddFlux).expectNext(11, 33).expectComplete().verify();
	}
	
	@Test
	void testFluxWithLog() {
		integerFlux
			.log()
			.map(num -> num * 4)
			.log()
			//.subscribe(data -> System.out.println(data));
			.subscribe();
	}
	
	@Test
	void testZip() {
		Flux<String> firstNames = Flux.just("Ravi", "Harish", "Vishnu", "Ramesh", "Vinay");
		Flux<String> lastNames = Flux.just("Kumar", "Mehta", "Vincent", "Rao");
		Flux<String> cities = Flux.just("Bangalore", "Mumbai", "Pune", "Chennai");
		
		
		Flux<Tuple3<String, String, String>> combineFlux = Flux.zip(firstNames, lastNames, cities);
		
		Flux<String> finalFlux = combineFlux
			.map(tuple -> tuple.getT1()+ " "+ tuple.getT2() + " lives in the city : "+tuple.getT3());
		
		finalFlux
		.log()
		.subscribe();
		
	}
	
	@Test
	void testZipWithMono() {
		Flux<Double> dollarFlux = Flux.just(100d);
		Mono<Double> dollarFactor = Mono.just(75d);
		Flux.zip(dollarFlux, dollarFactor)
		//blocking operation
		.map(tuple -> tuple.getT1()* tuple.getT2())
		.subscribe(result -> System.out.println(result));
	}
	
	@Test
	void testMapWithMono() {
		Flux<Double> dollarFlux = Flux.just(100d, 34.50, 450d, 500d);
		dollarFlux.map(amount -> amount * 75)
		//blocking operation
		.subscribe(result -> System.out.println(result));
	}
	
	@Test
	void testReduce() throws InterruptedException {
		
		Function<Integer, Integer> mapFunction = value -> value * 2;
		BiFunction<Integer, Integer, Integer> mapMaxValue = (input1, input2) -> Integer.max(input1, input2);
		BiFunction<Integer, Integer, Integer> mapMinValue = (input1, input2) -> Integer.min(input1, input2);
		
		Flux<Integer> delayElements = integerFlux.delayElements(Duration.of(2, ChronoUnit.SECONDS));
		Mono<Integer> maxValue = delayElements.reduce(mapMaxValue);
		//maxValue.subscribe(maxVal -> System.out.println(maxVal));
		integerFlux.reduce(mapMinValue).subscribe(minValue -> System.out.println(minValue));
		Thread.sleep(15000);
	}
	
	@Test
	void testConcatMapOperator() {
		Flux<String> firstNames = Flux.just("Ravi", "Harish", "Vishnu", "Ramesh", "Vinay");
		Flux<String> concatMapFlux = firstNames.concatMap(name -> Flux.just(name.split("")));
		concatMapFlux.subscribe(value -> System.out.println(value));
	}
	
	@Test
	void testConcatOperator() {
		Flux<String> firstNames = Flux.just("Ravi", "Harish", "Vishnu", "Ramesh", "Vinay");
		Flux<Double> scores = Flux.just(88d, 94d, 47d, 66d, 72d, 78d);
		Flux<Object> concatFlux = Flux.concat(firstNames, scores);
		//subscribing to the subsequent flux will be lazy in nature
		concatFlux.subscribe(value -> System.out.println(value));
	}
	
	@Test
	//for a given flux of empid, fetch their details
	void testSwithMapOperator() throws InterruptedException {
		integerFlux
			.switchMap(empId -> getEmployeeDetails(empId))
			.subscribe(res -> System.out.println(res));
		
		Thread.sleep(40000);
	}
	
	@Test
	void testDefaultIfEmpty() {
		Flux<String> users = Flux.just("Ravi", "Harish", "Vishnu", "Ramesh", "Vinay" ,"SK");
		
		Flux<String> usersWithLengthLessThan3 = users.filter(user -> user.length() < 3);
		
		usersWithLengthLessThan3.defaultIfEmpty("Default")
		.subscribe(val -> System.out.println(val));
	}
	
	@Test
	void testSwitchIfEmpty() {
		Flux<String> users = Flux.just("Ravi", "Harish", "Vishnu", "Ramesh", "Vinay" );
		
		Flux<String> usersWithLengthLessThan3 = users.filter(user -> user.length() < 3);
		
		usersWithLengthLessThan3.switchIfEmpty(fetchAlternateUsers())
		.subscribe(val -> System.out.println(val));
	}
	
	@Test
	void testMergeOperator() throws InterruptedException {
		Flux<String> usersInLowerCaseFlux = Flux.just("Ravi", "Harish", "Vishnu", "Ramesh", "Vinay")
								.map(String::toLowerCase)
								.delayElements(Duration.ofSeconds(2));
		Flux<String> usersInUpperCaseFlux = Flux.just("Ravi", "Harish", "Vishnu", "Ramesh", "Vinay")
				.map(String::toUpperCase)
				.delayElements(Duration.ofSeconds(3));
		
		Flux<String> mergedUsers = Flux.merge(usersInLowerCaseFlux, usersInUpperCaseFlux);
		mergedUsers.subscribe(user -> System.out.println(user));
		Thread.sleep(200000);
	}
	
	@Test
	void testWithErrorHandling() {
		Flux<Integer> integerFlux = Flux.just(1,2,3,4);
		Flux<Integer> finalFlux = integerFlux.concatWith(Flux.error(new RuntimeException("invlaid data")));
		finalFlux.subscribe(
				data -> System.out.println(data),
				(error) -> System.out.println(error.getMessage()),
				() -> System.out.println("This will not be called in this case")
				);
		StepVerifier.create(finalFlux)
					.expectNext(1,2,3,4)
					.expectError(RuntimeException.class)
					.verify();
	}
	
	@Test
	void testExceptionHandling() {
		Flux<Integer> integerFlux = Flux.just(1,2,3,4);
		Flux<Integer> finalFlux = integerFlux
									.concatWith(Flux.error(new RuntimeException("invlaid data")))
									.concatWith(Flux.just(11,22,33,44))
									//catch block
									.onErrorResume(error -> {
										System.out.println(error.getMessage());
										return Flux.empty();
									});
		
		finalFlux.subscribe(
				data -> System.out.println(data),
				(e) -> System.out.println("Error"+ e.getMessage()),
				() -> System.out.println("Successfully processed all the message")
				);

	}
	
	@Test
	void testExceptionHandlingWithReturn() {
		Flux<Integer> integerFlux = Flux.just(1,2,3,4);
		Flux<Integer> finalFlux = integerFlux
									.concatWith(Flux.error(new RuntimeException("invlaid data")))
									.concatWith(Flux.just(11,22,33,44))
									//catch block
									.onErrorReturn(100);
		
		finalFlux.subscribe(
				data -> System.out.println(data),
				(e) -> System.out.println("Error"+ e.getMessage()),
				() -> System.out.println("Successfully processed all the message")
				);

	}
	
	@Test
	void testDoOnNext() {
		Flux<String> strFlux = Flux.just("hello")
			.doOnNext(value -> {
			System.out.println("About to intoduce a delay");
			try {
				Thread.sleep(2000);
				System.out.println("Delay interval is completed ::");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		});
		strFlux.subscribe(data -> System.out.println(data));
	}
	
	@Test
	void testDoOnComplete() {
		Flux<String> strFlux = Flux.just("hello")
			.doOnComplete(() ->{
				System.out.println("The flux has completed..");
			});
		strFlux.subscribe(data -> System.out.println(data));
	}
	
	@Test
	void testDoOnError() {
		Flux<String> strFlux = Flux.just("hello")
			.concatWith(Flux.error(new RuntimeException("invalid data")))
			.doOnComplete(() ->{
				System.out.println("The flux has completed..");
			})
			.doOnError((error) -> {
				System.out.println("There was an error "+ error.getMessage());
			});
		strFlux.subscribe(data -> System.out.println(data));
	}

	
	private Flux<String> fetchAlternateUsers() {
		return Flux.just("Ravi", "Harish", "Vishnu", "Ramesh", "Vinay").map(String::toUpperCase);
	}
	private Flux<String> getEmployeeDetails(Integer empId){
		return Flux.just(empId + "-" + UUID.randomUUID().toString());
	}
}
