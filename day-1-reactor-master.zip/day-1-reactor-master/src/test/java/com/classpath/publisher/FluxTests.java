package com.classpath.publisher;

import java.time.Duration;
import java.time.temporal.ChronoUnit;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.util.function.Tuple2;

public class FluxTests {
	
	@Test
	void testMonoPublisher() {
		Mono<String> monoString = Mono.empty();
		StepVerifier stepVerifier = StepVerifier.create(monoString).expectComplete();
		stepVerifier.verify(Duration.of(5, ChronoUnit.SECONDS));
	}

	@Test
	void testSingleMonoPublisher() {
		Mono<String> stringMono = Mono.just("Reactive-programming");
		StepVerifier stepVerifier = StepVerifier.create(stringMono).expectNext("Reactive-programming").expectComplete();
		stepVerifier.verify(Duration.of(5, ChronoUnit.SECONDS));
	}
	
	@Test
	void testSubscribeMethod() {
		Flux<String> stringFlux =  Flux.just("one", "two", "three").delayElements(Duration.of(2, ChronoUnit.SECONDS));
		StepVerifier stepVerifier = StepVerifier.create(stringFlux).expectNext("one", "two", "three").expectComplete();
		stepVerifier.verify(Duration.of(8, ChronoUnit.SECONDS));
	}
	
	@Test
	void testErrorMethod() {
		Flux<String> stringFlux =  Flux.just("one", "two", "three")
										.concatWith(Mono.error(new RuntimeException("invalid data")));
		StepVerifier stepVerifier = StepVerifier
								.create(stringFlux)
								.expectNext("one", "two", "three")
								//.expectComplete();
								.expectError(RuntimeException.class);
		stepVerifier.verify(Duration.of(2, ChronoUnit.SECONDS));
	}

	@Test
	void testMapOperator() {
		//one input -> one output
		Flux<Integer> ageInYearsFlux = Flux.just(23, 45, 40, 56);
		Flux<Integer> ageInDays = ageInYearsFlux.map(ageInYear -> ageInYear * 365);
		
		StepVerifier.create(ageInDays)
					.expectNext(8395,16425,14600, 20440)
					.expectComplete()
					.verify(Duration.of(2, ChronoUnit.SECONDS));
	}
	
	@Test
	void testFilterOperator() {
		Flux<Integer> ageInYearsFlux = Flux.just(23, 45, 40, 56);
		Flux<Integer> ageInDays = ageInYearsFlux.filter(ageInYear -> ageInYear % 2  == 0);
		
		StepVerifier.create(ageInDays)
					.expectNext(40, 56)
					.expectComplete()
					.verify(Duration.of(2, ChronoUnit.SECONDS));
	}
	
	@Test
	void testAnyOperator() {
		Flux<Integer> numberFlux = Flux.just(23, 45, 40, 56, 100, 120, 200, 400);
		
		
		//short-circuit operator
		Mono<Boolean> numberGt100 = numberFlux.any(number -> number > 500);
		numberGt100.subscribe(value -> System.out.println(value));
		
		
		StepVerifier.create(numberGt100)
					.expectComplete()
					.verify(Duration.of(2, ChronoUnit.SECONDS));
	}
	
	@Test
	void testBlockFirstOperator() {
		Flux<Integer> numberFlux = Flux.just(23, 45, 40, 56, 100, 120, 200, 400);
		
		
		//short-circuit operator
		int firstNumber = numberFlux.blockFirst();
		System.out.println(firstNumber);
		Assertions.assertEquals(23, firstNumber);
	}
	
	
	@Test
	void testBlockLastOperator() {
		Flux<Integer> numberFlux = Flux.just(23, 45, 40, 56, 100, 120, 200, 400);
		
		
		//short-circuit operator
		int firstNumber = numberFlux.blockLast();
		System.out.println(firstNumber);
		Assertions.assertEquals(400, firstNumber);
	}
	
	
	@Test
	void testZipOperator() throws InterruptedException {
		Flux<String> letterFlux = Flux.just("a", "b", "c", "d","e").delayElements(Duration.of(1, ChronoUnit.SECONDS));
		Flux<Integer> numberFlux = Flux.just(1, 2, 3, 4).delayElements(Duration.of(2, ChronoUnit.SECONDS));
		
		Flux<Tuple2<String, Integer>> fluxTuple = letterFlux.zipWith(numberFlux);
		fluxTuple.subscribe(tuple -> System.out.println(tuple.get(0) + " "+tuple.get(1)));
		
		Thread.sleep(60000);
	}
}
