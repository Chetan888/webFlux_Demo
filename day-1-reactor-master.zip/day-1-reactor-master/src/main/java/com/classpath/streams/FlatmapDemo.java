package com.classpath.streams;

import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class FlatmapDemo {

	public static void main(String[] args) {

		int[][] twoDimArray = { { 1, 2 }, { 2, 3 }, { 3, 4 }, { 5, 6 } };
		// output - {1, 2, 2, 3, 3, 4, 5, 6}
		Stream<int[]> streamOfIntegerArray = Stream.of(twoDimArray);
		// output Stream<Integer> and not Stream<int[]>

		IntStream intStream = streamOfIntegerArray.flatMapToInt(Arrays::stream);
		intStream.distinct().forEach(System.out::println);

		// streamOfIntegerArray.forEach(System.out::println);

	}

}
