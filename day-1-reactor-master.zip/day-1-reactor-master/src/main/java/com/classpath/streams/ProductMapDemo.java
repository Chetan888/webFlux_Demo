package com.classpath.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;
import com.classpath.model.Product;
import com.github.javafaker.Faker;
import reactor.core.publisher.Flux;

public class ProductMapDemo {
	
	public static void main(String[] args) {
		Faker faker = new Faker();
		List<Product> products = new ArrayList<>();
		IntStream.range(0, 100)
				.forEach(index -> {
					Product product = Product
										.builder()
										.id(faker.number().randomNumber())
										.name(faker.commerce().productName())
										.price(faker.number().randomDouble(2, 500, 2000))
										.build();
					products.add(product);
				});
		
		//products.forEach(product -> System.out.println(product));
		Flux<Product> productFlux = Flux.fromIterable(products);
		productFlux
			.filter( p -> p.getPrice() > 1000)
			//.map(Product::getName)
			.subscribe(product -> System.out.println("Product name "+ product.getName() + "Price :: "+ product.getPrice()));
		
	}

}
