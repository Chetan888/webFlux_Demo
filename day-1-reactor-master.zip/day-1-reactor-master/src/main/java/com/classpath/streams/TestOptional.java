package com.classpath.streams;

import java.util.Optional;

import lombok.Data;

public class TestOptional {
	
	
	private static Optional<User> fetchUserById(long id) {
		return Optional.ofNullable(null);
	}
	
	
	public static void main(String[] args) {
		Optional<User> optionalUser = fetchUserById(12);
		/*
		 * boolean flag = optionalUser.isPresent(); System.out.println(flag);
		 */
		/*
		 * if(optionalUser.isPresent()) { System.out.println(optionalUser.get()); }else
		 * { System.out.println("No user present...."); }
		 */
		
		//optionalUser.ifPresent(user -> System.out.println(user));
		//User user = optionalUser.orElseThrow(() -> new IllegalArgumentException("invalid user id"));
		User user2 = optionalUser.orElse(new User(100));
		System.out.println(user2);
	}

}

@Data
class User{
	
	private long id;
	
	public User(long id) {
		this.id = id;
	}
	
}
