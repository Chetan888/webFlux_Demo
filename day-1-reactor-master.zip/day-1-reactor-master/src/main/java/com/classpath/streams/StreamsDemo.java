package com.classpath.streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class StreamsDemo {
	
	public static void main(String[] args) {
		
		Integer[] ages = {11, 23, 45, 16, 16, 56, 82, 33, 12, 18};
		
		List<Integer> agesLessThan18 = new ArrayList<>();
		//imperative style of programming
		/*
		 * for(int index = 0; index < ages.length; index++) { if (ages[index] < 18) {
		 * agesLessThan18.add(ages[index]); } } System.out.println(agesLessThan18);
		 */
		
		//declarative style of programming
		Predicate<Integer> ageLessThan18 = (age) -> age < 18;
		
		Function<Integer, Integer> mapYearToDays = year -> year * 365;
		
		Arrays.asList(ages)
				.stream()
				.filter(ageLessThan18)
				.map(mapYearToDays)
				.forEach(System.out::println);
		
		
		/*
		 * Predicate<Integer> ageBetween18And45 = (age) -> age > 18 && age < 45;
		 * 
		 * Arrays.asList(ages).stream().filter(ageBetween18And45).forEach(System.out::
		 * println);
		 */		
	}

}
