package com.classpath.core;

import java.util.function.Consumer;
import java.util.function.Function;

import reactor.core.publisher.Flux;

public class FluxOperators {
	
	public static void main(String[] args) {
		Integer[] array = {11,22,33,44,55};
		Flux<Integer> arrayFlux = Flux.fromArray(array);
		
		Function<Integer, Integer> mapValueTo10Multiplier = value -> value * 10;
		
		Consumer<Integer> printValueConsumer = System.out::println;
		
		Flux<Integer> valueMultiplier = arrayFlux.map(mapValueTo10Multiplier);
		
		valueMultiplier.subscribe(printValueConsumer);
	}

}
