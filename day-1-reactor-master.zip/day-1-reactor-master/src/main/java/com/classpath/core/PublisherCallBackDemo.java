package com.classpath.core;

import reactor.core.publisher.Flux;

public class PublisherCallBackDemo {
	
	public static void main(String[] args) {
		Integer[] array = {11,22,33,44,55};
		Flux<Integer> arrayFlux = Flux.fromArray(array);
		
		arrayFlux.subscribe(
				(value) -> 	System.out.println(value),
				(error) -> System.out.println("on error "+ error),
				() -> System.out.println("Subscription is completed :: No more data")
		);
	}

}
