package com.classpath.core;

import static java.time.temporal.ChronoUnit.SECONDS;

import java.time.Duration;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import reactor.core.publisher.Flux;

/**
 * Subscribing for data and processing by applying the filter, map and reduce function
 * @author pradeep
 *
 */
public class SubscriberDemo {
	
	public static void main(String[] args) throws InterruptedException {
		Flux<Integer> numbers = Flux
				.just(10, 11, 12, 13,14, 45, 67, 54,22)
				.delayElements(Duration.of(2, SECONDS));
		
		Predicate<Integer> ageLessThan18 = (age) -> age < 18;

		Function<Integer, Integer> mapYearToDays = year -> year * 365;
		
		Consumer<Integer> printAgeConsumer = age -> System.out.println(age);
		
		/*
		 * Flux<Integer> filteredAges = numbers.filter(ageLessThan18); Flux<Integer>
		 * agesInDays = filteredAges.map(mapYearToDays);
		 * 
		 * agesInDays.subscribe(printAgeConsumer);
		 */
		
		numbers.filter(ageLessThan18)
			   .map(mapYearToDays)
			   .subscribe(printAgeConsumer);
		
		
		Thread.sleep(50000);
	}

}
