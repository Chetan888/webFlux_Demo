package com.classpath.core;

import static java.time.temporal.ChronoUnit.SECONDS;

import java.time.Duration;
import java.util.concurrent.CountDownLatch;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import reactor.core.publisher.Flux;

public class FluxPublisherDemo {
	
	public static void main(String[] args) throws InterruptedException {
		
		Flux<Integer> number = Flux.just(34);
		Flux<Integer> numbers = Flux
									.just(10, 11, 12, 13,14, 45, 67, 54,22)
									.delayElements(Duration.of(2, SECONDS));
		
		
		//number.subscribe((data) -> System.out.println(data));
		
		System.out.println(numbers);
		
		//numbers.subscribe(value -> System.out.println(value));
		
		CountDownLatch latch = new CountDownLatch(1);
		numbers.subscribe(new Subscriber<Integer>() {

			private Subscription subscription;

			@Override
			public void onSubscribe(Subscription subscription) {
				this.subscription = subscription;
				subscription.request(2);
				
			}

			@Override
			public void onNext(Integer number) {
				System.out.println(number);
				this.subscription.request(2);
				if (number == 214) {
					this.subscription.cancel();
				}
			}

			@Override
			public void onError(Throwable exception) {
				System.out.println("Exception :: "+ exception.getMessage());
				
			}

			@Override
			public void onComplete() {
				System.out.println("Subscription is complete. No more data will be produced....");
				latch.countDown();
			}
			
		});
		
		Thread.sleep(20000);
		
		
	}

}
