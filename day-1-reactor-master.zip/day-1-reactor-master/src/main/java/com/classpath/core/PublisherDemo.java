package com.classpath.core;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import reactor.core.publisher.Mono;

public class PublisherDemo {
	
	public static void main(String[] args) {
		/*
		 * Publishers
		 * Mono<T> - 0 .. 1
		 * Flux<T> - 0 .. n
		 */
		
		Mono<Integer> monoNumber = Mono.just(34);
		int value = 34;
		/*
		 * System.out.println("Value is "+ value); 
		 * System.out.println("number is "+ monoNumber);
		 */
		
		//publishers are lazy in nature
		// the data will not be published until the subscriber subscribes to the publisher
		
		/*monoNumber
			.subscribe((data) -> System.out.println(data));
			*/
		
		monoNumber.subscribe(new Subscriber<Integer>() {

			private Subscription subscription;

			@Override
			public void onSubscribe(Subscription subscription) {
				this.subscription = subscription;
				subscription.request(1);
				
			}

			@Override
			public void onNext(Integer value) {
				System.out.println("Value :: "+ value);
				
			}

			@Override
			public void onError(Throwable exception) {
				System.out.println("Exception :: "+ exception.getMessage());
				
			}

			@Override
			public void onComplete() {
				System.out.println("Subscription is complete. No more data will be produced....");
			}
		});
	}

}
