package com.classpath.core;

import reactor.core.publisher.Flux;

public class PublisherExceptionDemo {

	public static void main(String[] args) throws InterruptedException {

		Flux<Integer> numbers = Flux
									.just(10, 11, 12, 13, 14, 45, 67, 54, 22)
									.concatWith(Flux.error(new IllegalArgumentException("invalid data")))
									.concatWith(Flux.just(500, 600, 700));
		
		numbers.subscribe(
				(data) -> System.out.println(data),
				(error) -> System.out.println("error while processing the data "+error),
				() -> System.out.println("All data is consumed")
				);
	}
}
