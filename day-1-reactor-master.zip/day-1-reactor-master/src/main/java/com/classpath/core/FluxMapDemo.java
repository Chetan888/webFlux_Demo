package com.classpath.core;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.IntStream;

import com.classpath.model.LineItem;
import com.classpath.model.Order;
import com.github.javafaker.Faker;

import reactor.core.publisher.Flux;

public class FluxMapDemo {
	
	/**
	 * Flux<Integer[]> => flatmap => Flux<Integer>
	 * Flux<List<Integer> => flatMap => Flux<Integer>
	 * Flux<Set<Integer> => flatMap => Flux<Integer>
	 * Flux<Stream<Integer> => flatMap => Flux<Integer>
	 * Flux<Flux<Integer> => flatMap => Flux<Integer>
	 * Flux<Integer> => flatMap => Flux<Integer>
	 */
	public static void main(String[] args) {
		Flux<Order> orderFlux = fetchAllOrders();
		Flux<String> emailFlux = orderFlux.map(order -> order.getEmail());
		Flux<Long> idFlux = orderFlux.map(order -> order.getId());
		Flux<Set<LineItem>> lineItemFromSetFlux = orderFlux.map(Order::getLineItems);
		Flux<LineItem> lineItemsFlux =  lineItemFromSetFlux.flatMap(lineItems -> Flux.fromIterable(lineItems));
		lineItemsFlux.distinct().subscribe(li -> System.out.println(li.getName()));
	}

	private static Flux<Order> fetchAllOrders() {

		Faker faker = new Faker();
		
		Set<Order> orders = new HashSet<>();
		
		IntStream.range(0, 100)
				.forEach(index -> {
					Order order = Order.builder()
										.email(faker.internet().emailAddress())
										.id(faker.number().randomNumber())
										.lineItems(new HashSet<>())
										.build();
					IntStream.range(1, 5)
							.forEach(val -> {
								LineItem lineItem = LineItem.builder()
															.name(faker.commerce().productName())
															.price(faker.number().randomDouble(2, 1000, 2000))
															.qty(faker.number().numberBetween(2, 5))
															.build();
								order.getLineItems().add(lineItem);
							});
					orders.add(order);
				});
		return Flux.fromIterable(orders);
	}

}
