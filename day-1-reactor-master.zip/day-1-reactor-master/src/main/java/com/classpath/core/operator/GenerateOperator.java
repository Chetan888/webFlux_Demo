package com.classpath.core.operator;

import reactor.core.publisher.Flux;

public class GenerateOperator {
	
	public static void main(String[] args) {
		
		Flux<String> fluxOfMultiples = Flux.generate(
			    () -> 0, //initial state 
			    (state, sink) -> {
			      sink.next("3 x " + state + " = " + 3*state); 
			      if (state == 10) sink.complete(); 
			      return state + 1; 
			    });
		
		fluxOfMultiples.subscribe(value -> System.out.println(value));
	}

}
