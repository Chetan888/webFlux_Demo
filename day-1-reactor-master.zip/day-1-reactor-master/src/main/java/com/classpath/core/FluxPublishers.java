package com.classpath.core;

import java.util.List;
import java.util.stream.Stream;

import reactor.core.publisher.Flux;

public class FluxPublishers {
	
	public static void main(String[] args) {
		Flux<Integer> oneFlux = Flux.just(23);
		
		Flux<Integer> manyFlux = Flux.just(11,22,33,44,55);
		
		Integer[] array = {11,22,33,44,55};
		Flux<Integer> arrayFlux = Flux.fromArray(array);
		
		List<Integer> list = List.of(1, 2, 3, 4, 5, 6, 7, 8);
		Flux<Integer> listFlux = Flux.fromIterable(list);
		
		Stream<Integer> intStream = list.stream();
		
		Flux<Integer> streamFlux = Flux.fromStream(intStream);
		
		Flux<Integer> emptyFlux = Flux.empty();
		
		Flux<Integer> generateFlux = Flux.range(1, 5);
	}

}
