package com.classpath.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class LineItem {
	
	private String name;
	private double price;
	private int qty;

}
